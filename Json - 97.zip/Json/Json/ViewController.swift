
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let website=URL(string: "http://api.fixer.io/latest")
        let task=URLSession.shared.dataTask(with: website!) { (data, response, err) in
            
            if err != nil
            {
              print("failed")
            }
            else
            {
                if let myContact=data
                {
                    do
                    {
                        let myJson=try JSONSerialization.jsonObject(with: myContact, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
//                        print(myJson)
                       let rates=myJson["rates"] as! NSDictionary
                        let dollar=rates["USD"]
                        print(dollar!)
                        
                    }
                        
                        
                    catch
                    {
                        
                    }
                }
                
            }
            
        }
        task.resume()
    }

    


}

